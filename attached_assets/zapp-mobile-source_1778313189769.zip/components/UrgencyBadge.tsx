import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { useColors } from '@/hooks/useColors';
import { Urgency } from '@/context/TaskContext';

const LABELS: Record<Urgency, string> = {
  now: '🔥 NOW',
  soon: '⏰ SOON',
  later: '🌙 LATER',
  brain: '🧠 BRAIN',
};

export default function UrgencyBadge({ urgency }: { urgency: Urgency }) {
  const colors = useColors();
  const bg: Record<Urgency, string> = {
    now: `${colors.now}22`,
    soon: `${colors.soon}22`,
    later: `${colors.later}22`,
    brain: `${colors.brain}22`,
  };
  const fg: Record<Urgency, string> = {
    now: colors.now,
    soon: colors.soon,
    later: colors.later,
    brain: colors.brain,
  };
  return (
    <View style={[styles.badge, { backgroundColor: bg[urgency] }]}>
      <Text style={[styles.text, { color: fg[urgency] }]}>{LABELS[urgency]}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  badge: {
    alignSelf: 'flex-start',
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: 6,
    marginTop: 6,
  },
  text: {
    fontSize: 11,
    fontWeight: '800',
    letterSpacing: 0.5,
  },
});
