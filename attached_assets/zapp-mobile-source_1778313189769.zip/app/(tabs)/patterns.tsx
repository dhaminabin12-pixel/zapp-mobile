import { Feather } from '@expo/vector-icons';
import { router } from 'expo-router';
import React from 'react';
import {
  Platform,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useTasks } from '@/context/TaskContext';
import { useColors } from '@/hooks/useColors';

export default function PatternsScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { patterns } = useTasks();

  const topPad = Platform.OS === 'web' ? 67 : insets.top;

  const getLevel = (score: number) => {
    if (score >= 4.5) return { label: 'Very High', color: colors.now };
    if (score >= 3.5) return { label: 'High', color: colors.soon };
    if (score >= 2.5) return { label: 'Moderate', color: colors.yellow };
    if (score >= 1.5) return { label: 'Mild', color: colors.later };
    return { label: 'Low', color: colors.success };
  };

  return (
    <ScrollView
      style={[styles.root, { backgroundColor: colors.background }]}
      contentContainerStyle={[styles.content, { paddingTop: topPad + 8, paddingBottom: insets.bottom + 100 }]}
      showsVerticalScrollIndicator={false}
    >
      <View style={styles.header}>
        <Text style={[styles.title, { color: colors.foreground }]}>🧠 Your Patterns</Text>
        <Text style={[styles.sub, { color: colors.mutedForeground }]}>
          Understanding your brain helps you work with it
        </Text>
      </View>

      {!patterns ? (
        <View style={[styles.emptyCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <Text style={styles.emptyEmoji}>🔬</Text>
          <Text style={[styles.emptyTitle, { color: colors.foreground }]}>No assessment yet</Text>
          <Text style={[styles.emptyText, { color: colors.mutedForeground }]}>
            Take the 80-question ADHD pattern assessment to understand your unique brain profile.
          </Text>
          <TouchableOpacity
            style={[styles.assessBtn, { backgroundColor: colors.primary }]}
            onPress={() => router.push('/assessment')}
            activeOpacity={0.85}
          >
            <Text style={styles.assessBtnText}>Take Assessment →</Text>
          </TouchableOpacity>
          <Text style={[styles.timeHint, { color: colors.mutedForeground }]}>~10 minutes · 80 questions · 8 categories</Text>
        </View>
      ) : (
        <>
          <TouchableOpacity
            style={[styles.retakeBtn, { backgroundColor: colors.muted, borderColor: colors.border }]}
            onPress={() => router.push('/assessment')}
          >
            <Feather name="refresh-cw" size={14} color={colors.mutedForeground} />
            <Text style={[styles.retakeBtnText, { color: colors.mutedForeground }]}>Retake Assessment</Text>
          </TouchableOpacity>

          {patterns.map((cat, i) => {
            const level = getLevel(cat.score);
            const pct = ((cat.score - 1) / 4) * 100;
            return (
              <View key={i} style={[styles.catCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
                <View style={styles.catHead}>
                  <Text style={[styles.catName, { color: colors.foreground }]}>{cat.category}</Text>
                  <View style={[styles.levelBadge, { backgroundColor: `${level.color}22` }]}>
                    <Text style={[styles.levelText, { color: level.color }]}>{level.label}</Text>
                  </View>
                </View>
                <View style={[styles.catBar, { backgroundColor: colors.muted }]}>
                  <View style={[styles.catFill, { width: `${pct}%` as any, backgroundColor: cat.color || level.color }]} />
                </View>
                <Text style={[styles.scoreText, { color: colors.mutedForeground }]}>
                  Score: {cat.score.toFixed(1)} / 5
                </Text>
                {cat.solutions && cat.solutions.length > 0 && (
                  <View style={styles.solutions}>
                    <Text style={[styles.solutionsTitle, { color: colors.foreground }]}>Evidence-based strategies:</Text>
                    {cat.solutions.slice(0, 3).map((sol, si) => (
                      <View key={si} style={styles.solutionRow}>
                        <View style={[styles.solDot, { backgroundColor: cat.color || colors.primary }]} />
                        <Text style={[styles.solutionText, { color: colors.mutedForeground }]}>{sol}</Text>
                      </View>
                    ))}
                  </View>
                )}
              </View>
            );
          })}
        </>
      )}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1 },
  content: { paddingHorizontal: 16 },
  header: { marginBottom: 16 },
  title: { fontSize: 26, fontWeight: '900', fontFamily: 'Inter_700Bold', marginBottom: 4 },
  sub: { fontSize: 14, fontWeight: '600' },
  emptyCard: {
    borderRadius: 20,
    borderWidth: 2,
    padding: 24,
    alignItems: 'center',
    gap: 10,
  },
  emptyEmoji: { fontSize: 56, marginBottom: 4 },
  emptyTitle: { fontSize: 22, fontWeight: '900', textAlign: 'center' },
  emptyText: { fontSize: 14, fontWeight: '600', textAlign: 'center', lineHeight: 20 },
  assessBtn: {
    paddingVertical: 16,
    paddingHorizontal: 32,
    borderRadius: 16,
    marginTop: 8,
    width: '100%',
    alignItems: 'center',
  },
  assessBtnText: { color: '#fff', fontSize: 17, fontWeight: '900' },
  timeHint: { fontSize: 12, fontWeight: '600' },
  retakeBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    alignSelf: 'flex-start',
    borderRadius: 999,
    borderWidth: 1.5,
    paddingHorizontal: 14,
    paddingVertical: 7,
    marginBottom: 14,
  },
  retakeBtnText: { fontSize: 13, fontWeight: '700' },
  catCard: {
    borderRadius: 16,
    borderWidth: 2,
    padding: 14,
    marginBottom: 10,
  },
  catHead: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 },
  catName: { fontSize: 16, fontWeight: '800' },
  levelBadge: { paddingHorizontal: 10, paddingVertical: 3, borderRadius: 8 },
  levelText: { fontSize: 12, fontWeight: '800' },
  catBar: { height: 8, borderRadius: 999, overflow: 'hidden', marginBottom: 6 },
  catFill: { height: '100%', borderRadius: 999 },
  scoreText: { fontSize: 12, fontWeight: '700', marginBottom: 8 },
  solutions: { gap: 4 },
  solutionsTitle: { fontSize: 13, fontWeight: '800', marginBottom: 4 },
  solutionRow: { flexDirection: 'row', gap: 8, alignItems: 'flex-start' },
  solDot: { width: 6, height: 6, borderRadius: 3, marginTop: 6, flexShrink: 0 },
  solutionText: { flex: 1, fontSize: 13, fontWeight: '600', lineHeight: 18 },
});
